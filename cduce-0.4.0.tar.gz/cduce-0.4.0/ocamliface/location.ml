open Lexing
type t = { loc_start: position; loc_end: position; loc_ghost: bool }
